<?php $__env->startSection('title', "MoneyQ - Home"); ?>

<?php $__env->startSection('content'); ?>
    <a href="/" class="title">MoneyQ</a>
    <div class="wrapper">
        <div class="block wide">
            <h3><?php echo e(__('messages.welcome')); ?></h3>
            <p><?php echo e(__('messages.introduction')); ?></p>
        </div>

        <div class="buttons">
            <a class="light large" href="<?php echo e(route('login')); ?>"><?php echo e(__('messages.buttons.login')); ?></a>
            <a class="light large" href="<?php echo e(route('register')); ?>"><?php echo e(__('messages.buttons.register')); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\moneyquest\resources\views/welcome.blade.php */ ?>