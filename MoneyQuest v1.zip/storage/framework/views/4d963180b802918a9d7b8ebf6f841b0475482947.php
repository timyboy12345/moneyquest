<?php $__env->startSection('title', "MoneyQ - Home"); ?>

<?php $__env->startSection('content'); ?>
    <a href="/" class="title">MoneyQ</a>
    <div class="wrapper">
        <div class="block">
            <h3 class="text-center"><?php echo e(__('messages.buttons.login')); ?></h3>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="formline">
                    <label for="email"><?php echo e(__('messages.words.email')); ?></label>
                    <input required type="email" placeholder="<?php echo e(__('messages.words.email')); ?>" name="email" id="email">
                    <?php if($errors->has('email')): ?>
                        <span class="alert red">
                            <?php echo e($errors->first('email')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="formline">
                    <label for="email"><?php echo e(__('messages.words.password')); ?></label>
                    <input required type="password" placeholder="<?php echo e(__('messages.words.password')); ?>" name="password"
                           id="password">
                    <?php if($errors->has('password')): ?>
                        <span class="alert red">
                            <?php echo e($errors->first('password')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <input class="button" type="submit">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\moneyquest\resources\views/login/index.blade.php */ ?>