<?php $__env->startSection('title', "MoneyQ - Home"); ?>

<?php $__env->startSection('content'); ?>
    <a href="/" class="title">MoneyQ</a>
    <div class="wrapper">
        <div class="block">
            <h3><?php echo e(__('messages.welcome')); ?></h3>
            <ul>
                <li><?php echo e(Auth::user()->name); ?></li>
                <li><?php echo e(Auth::user()->email); ?></li>
            </ul>
        </div>

        <div class="block">
            <h3><?php echo e(__("messages.dashboard.youraccounts")); ?></h3>
            <ul>
                <?php $__currentLoopData = $bank_accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($account->iban); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="buttons small">
                <a href="<?php echo e(route('bankaccounts')); ?>" class="button small"><?php echo e(__("messages.dashboard.manageaccounts")); ?></a>
            </div>
        </div>

        <div class="buttons">
            <a class="light large" href="<?php echo e(route('logout')); ?>"><?php echo e(__('messages.buttons.logout')); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\moneyquest\resources\views/dashboard/index.blade.php */ ?>