<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOLLIE ERROR</title>
</head>
<body>
    <h1>Er was een error</h1>
    <p><?php echo e($error); ?></p>
</body>
</html>
<?php /* D:\moneyquest\resources\views/mollie/error.blade.php */ ?>