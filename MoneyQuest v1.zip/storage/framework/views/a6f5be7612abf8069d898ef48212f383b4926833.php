<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'MoneyQ'); ?></title>

    <link href="/css/default.css" rel="stylesheet" type="text/css">
    <link href="/css/form.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan" rel="stylesheet">

</head>
<body>
<?php echo $__env->yieldContent('content'); ?>

<div class="footer">
    <div class="wrapper">
        <div class="buttons">
            <a class="button small" href="<?php echo e(route('lang', 'nl')); ?>">Nederlands</a>
            <a class="button small" href="<?php echo e(route('lang', 'en')); ?>">English</a>
        </div>
    </div>
</div>
</body>
</html>
<?php /* D:\moneyquest\resources\views/layout/master.blade.php */ ?>