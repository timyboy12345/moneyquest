<?php $__env->startSection('title', "MoneyQ - Home"); ?>

<?php $__env->startSection('content'); ?>
    <a href="/" class="title">MoneyQ</a>
    <div class="wrapper">
        <div class="block wide">
            <h3><?php echo e(__("messages.dashboard.youraccounts")); ?></h3>
            <ul>
                <?php $__currentLoopData = $bank_accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($account->iban); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <form method="post">
                <?php echo csrf_field(); ?>

                <div class="formline">
                    <label for="account"><?php echo e(__('messages.words.bankaccount')); ?></label>
                    <input required name="account" placeholder="<?php echo e(__('messages.words.bankaccount')); ?>" type="text">

                    <?php if($errors->has('account')): ?>
                        <div class="alert red">
                            <?php echo e($errors->first('account')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <input type="submit">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\moneyquest\resources\views/dashboard/bankaccounts.blade.php */ ?>